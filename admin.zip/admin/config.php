<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = ""; // Assuming no password
$dbname = "user_db";

// Create connection
$db = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>
