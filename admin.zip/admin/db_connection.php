<?php
$servername = "localhost";
$dbname = "user_db";

// Create connection
$conn = new mysqli('localhost','root','','user_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
