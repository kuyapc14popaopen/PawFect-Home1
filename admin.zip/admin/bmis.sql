SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: bmis
--

-- --------------------------------------------------------

--
-- Table structure for table tbl_admin
--

CREATE TABLE tbl_admin (
  id_admin int(11) NOT NULL,
  email varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  role varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_admin
--

INSERT INTO tbl_admin (id_admin, email, password, lname, fname, mi, role) VALUES
(1, 'admin1@gmail.com', '********', 'Tosper', 'Rafael Jr.', 'M', 'administrator'),
(2, 'admin2@gmail.com', '********', 'Simon', 'Marian', 'C', 'administrator'),
(3, 'admin3@gmail.com', '********', 'Obena', 'Katrina', 'T', 'administrator'),
(4, 'admin4@gmail.com', '********', 'Villano', 'Kristine Joy', 'G', 'administrator'),
(5, 'admin5@gmail.com', '********', 'Mangalino', 'Jayvee', 'T', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table tbl_announcement
--

CREATE TABLE tbl_announcement (
  id_announcement int(11) NOT NULL,
  event varchar(1000) NOT NULL,
  target varchar(255) DEFAULT NULL,
  start_date date NOT NULL,
  addedby varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_announcement
--

INSERT INTO tbl_announcement (id_announcement, event, target, start_date, addedby) VALUES
(6, 'Free Consultations available from June 13, 2021 until June 25, 2021', NULL, '2021-06-12', 'vilfamat, vincent');

-- --------------------------------------------------------

--
-- Table structure for table tbl_blotter
--

CREATE TABLE tbl_blotter (
  id_blotter int(11) NOT NULL,
  id_resident int(11) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  houseno varchar(255) NOT NULL,
  street varchar(255) NOT NULL,
  brgy varchar(255) NOT NULL,
  municipal varchar(255) NOT NULL,
  blot_photo mediumblob NOT NULL,
  contact int(20) NOT NULL,
  narrative mediumtext NOT NULL,
  timeapplied datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_blotter
--

INSERT INTO tbl_blotter (id_blotter, id_resident, lname, fname, mi, houseno, street, brgy, municipal, blot_photo, contact, narrative, timeapplied) VALUES
(1, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', '', 2147483647, 'sinakal tas binalibag pusa namin', '2021-06-30 09:17:36'),
(2, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', '', 2147483647, 'pinalo yung aso namen', '2021-06-30 09:43:46'),
(3, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', 0x4172726179, 2147483647, 'hinataw yung aso namin', '2021-06-30 09:54:15'),
(4, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', 0x4172726179, 2147483647, 'pinalo yung aso ko ng kapitbahay', '2021-06-30 13:35:51');

-- --------------------------------------------------------

--
-- Table structure for table tbl_brgyid
--

CREATE TABLE tbl_brgyid (
  id_brgyid int(11) DEFAULT NULL,
  id_resident int(11) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  houseno varchar(255) NOT NULL,
  street varchar(255) NOT NULL,
  brgy varchar(255) NOT NULL,
  municipal varchar(255) NOT NULL,
  bplace varchar(255) NOT NULL,
  bdate varchar(255) NOT NULL,
  res_photo varchar(255) DEFAULT NULL,
  inc_lname varchar(255) NOT NULL,
  inc_fname varchar(255) NOT NULL,
  inc_mi varchar(255) NOT NULL,
  inc_contact varchar(255) NOT NULL,
  inc_houseno varchar(255) NOT NULL,
  inc_street varchar(255) NOT NULL,
  inc_brgy varchar(255) NOT NULL,
  inc_municipal varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_brgyid
--

INSERT INTO tbl_brgyid (id_brgyid, id_resident, lname, fname, mi, houseno, street, brgy, municipal, bplace, bdate, res_photo, inc_lname, inc_fname, inc_mi, inc_contact, inc_houseno, inc_street, inc_brgy, inc_municipal) VALUES

(NULL, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', '2011-06-15', '1999-07-30', NULL, 'Vilfamat', 'Teresita', 'Briongos', '09515496436', 'Antipolo City', '2011-06-15', '1999-07-30', NULL),
(NULL, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', '2011-06-15', '1999-11-29', NULL, 'Vilfamat', 'Teresita', 'Briongos', '09654165465', 'Antipolo City', '2011-06-15', '1999-11-29', 'Array'),
(NULL, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', 'Antipolo, Rizal', '1999-11-30', NULL, 'Vilfamat', 'Teresita', 'Briongos', '09564815496', 'Antipolo City', 'Antipolo, Rizal', '1999-11-30', 'Array');

-- --------------------------------------------------------

--
-- Table structure for table tbl_bspermit
--

CREATE TABLE tbl_bspermit (
  id_bspermit int(11) NOT NULL,
  id_resident int(11) NOT NULL,
  lname varchar(255) DEFAULT NULL,
  fname varchar(255) DEFAULT NULL,
  mi varchar(255) DEFAULT NULL,
  bsname varchar(255) DEFAULT NULL,
  houseno varchar(255) DEFAULT NULL,
  street varchar(252) DEFAULT NULL,
  brgy varchar(255) DEFAULT NULL,
  municipal varchar(255) DEFAULT NULL,
  bsindustry varchar(255) DEFAULT NULL,
  aoe int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_bspermit
--

INSERT INTO tbl_bspermit (id_bspermit, id_resident, lname, fname, mi, bsname, houseno, street, brgy, municipal, bsindustry, aoe) VALUES
(1, 31, 'Rodriguez', 'Rori', 'Sabaw', 'Salami Store', 'Blk. 31 Lot 5 ', 'Quinto', 'Dalig', 'Antipolo', 'Food', 25),
(2, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Pizza Store', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', 'Food', 25);

-- --------------------------------------------------------

--
-- Table structure for table tbl_clearance
--

CREATE TABLE tbl_clearance (
  id_clearance int(11) NOT NULL,
  id_resident int(11) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  purpose varchar(255) NOT NULL,
  houseno varchar(255) NOT NULL,
  street varchar(255) NOT NULL,
  brgy varchar(255) NOT NULL,
  municipal varchar(255) NOT NULL,
  status varchar(255) NOT NULL,
  age varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_clearance
--

INSERT INTO tbl_clearance (id_clearance, id_resident, lname, fname, mi, purpose, houseno, street, brgy, municipal, status, age) VALUES
(1, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Job Requirement', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', 'Single', '21');

-- --------------------------------------------------------

--
-- Table structure for table tbl_indigency
--

CREATE TABLE tbl_indigency (
  id_indigency int(11) NOT NULL,
  id_resident int(11) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  nationality varchar(255) NOT NULL,
  houseno varchar(255) NOT NULL,
  street varchar(255) NOT NULL,
  brgy varchar(255) NOT NULL,
  municipal varchar(255) NOT NULL,
  purpose varchar(255) DEFAULT NULL,
  date date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_indigency
--

INSERT INTO tbl_indigency (id_indigency, id_resident, lname, fname, mi, nationality, houseno, street, brgy, municipal, purpose, date) VALUES
(1, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Filipino', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', 'Financial Assistance', '2021-06-30'),
(2, 23, 'Vilfamat', 'Vincent', 'Briongos', 'Filipino', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', 'Scholarship', '2021-06-30');

-- --------------------------------------------------------

--
-- Table structure for table tbl_rescert
--

CREATE TABLE tbl_rescert (
  id_rescert int(11) NOT NULL,
  id_resident int(11) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  age varchar(255) NOT NULL,
  nationality varchar(255) DEFAULT NULL,
  houseno varchar(255) NOT NULL,
  street varchar(255) NOT NULL,
  brgy varchar(255) NOT NULL,
  municipal varchar(255) NOT NULL,
  date date NOT NULL,
  purpose varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_rescert
--

INSERT INTO tbl_rescert (id_rescert, id_resident, lname, fname, mi, age, nationality, houseno, street, brgy, municipal, date, purpose) VALUES
(1, 23, 'Vilfamat', 'Vincent', 'Briongos', '21', 'Filipino', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', '2021-06-30', 'Job/Employment'),
(111110, 23, 'Vilfamat', 'Vincent', 'Briongos', '21', 'Filipino', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', '2021-06-30', 'Job/Employment'),
(111111, 23, 'Vilfamat', 'Vincent', 'Briongos', '21', 'Filipino', 'Blk. 2 Lot 5', 'Kamatisan', 'Dalig', 'Antipolo City', '2021-07-03', 'Job/Employment');

-- --------------------------------------------------------

--
-- Table structure for table tbl_resident
--

CREATE TABLE tbl_resident (
  id_resident int(11) NOT NULL,
  res_photo mediumblob DEFAULT NULL,
  email varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  age int(11) NOT NULL,
  sex varchar(255) NOT NULL,
  status varchar(255) NOT NULL,
  houseno varchar(255) DEFAULT NULL,
  street varchar(255) DEFAULT NULL,
  brgy varchar(255) DEFAULT NULL,
  municipal varchar(255) DEFAULT NULL,
  address varchar(255) DEFAULT NULL,
  contact varchar(255) NOT NULL,
  bdate date NOT NULL,
  bplace varchar(255) NOT NULL,
  nationality varchar(255) NOT NULL,
  family_role varchar(255) NOT NULL,
  voter varchar(255) DEFAULT NULL,
  role varchar(255) NOT NULL,
  addedby varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_resident
--

INSERT INTO tbl_resident (id_resident, res_photo, email, password, lname, fname, mi, age, sex, status, houseno, street, brgy, municipal, address, contact, bdate, bplace, nationality, family_role, voter, role, addedby) VALUES
(25, '', 'jun@gmail.com', 'jun12345', 'Trinidad', 'Jun', 'Gabbo', 21, 'Male', 'Single', 'Blk. 13 Lot 10', 'El Chapo', 'Dalig', 'Antipolo', '', '09486715528', '1992-06-09', 'Antipolo, Rizal', 'Filipino', 'No', 'Yes', 'resident', NULL),
(26, NULL, 'eduardo@gmail.com', 'eduardo12345', 'Santos', 'Eduardo', 'Espiritu', 41, 'Male', 'Married', 'Blk. 14 Lot 25', 'El Chapo', 'Dalig', 'Antipolo', '', '09785462214', '1971-06-10', 'Camarines Sur', 'Filipino', 'Yes', 'Yes', 'resident', NULL),
(27, NULL, 'juan@gmail.com', 'juan12345', 'Trinidad', 'Juan', 'Gabbo', 41, 'Male', 'Married', 'Blk. 13 Lot 10', 'El Chapo', 'Dalig', 'Antipolo', '', '02185461245', '1971-06-10', 'Quezon City', 'Filipino', 'Yes', 'Yes', 'resident', NULL),
(28, NULL, 'mica@gmail.com', 'mica12345', 'Galicia', 'Mica', 'Puerto', 22, 'Female', 'Single', 'Blk. 2 Lot 15', 'Kamatisan', 'Dalig', 'Antipolo', '', '09512347756', '1983-06-15', 'Quezon City', 'Filipino', 'Yes', 'Yes', 'resident', NULL),
(31, NULL, 'rori@gmail.com', 'rori12345', 'Rodriguez', 'Rori', 'Sabaw', 35, 'Female', 'Single', 'Blk. 31 Lot 5 ', 'Quinto', 'Dalig', 'Antipolo', NULL, '09425465462', '2021-06-10', 'Antipolo, Rizal', 'Filipino', 'Yes', 'Yes', 'resident', NULL);

-- --------------------------------------------------------

--
-- Table structure for table tbl_user
--

CREATE TABLE tbl_user (
  id_user int(11) NOT NULL,
  email varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  lname varchar(255) NOT NULL,
  fname varchar(255) NOT NULL,
  mi varchar(255) NOT NULL,
  age int(20) NOT NULL,
  sex varchar(255) NOT NULL,
  address varchar(255) NOT NULL,
  contact varchar(255) NOT NULL,
  position varchar(255) NOT NULL,
  role varchar(255) NOT NULL,
  addedby varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table tbl_user
--

INSERT INTO tbl_user (id_user, email, password, lname, fname, mi, age, sex, address, contact, position, role, addedby) VALUES
(11, 'melinda@gmail.com', 'melinda12345', 'Gomez', 'Melinda', 'Paz', 35, 'Female', 'Blk. 12 Lot 10 Kamatisan', '09564123321', 'Barangay Secretary', 'user', 'Vilfamat, Vincent'),
(12, 'earl@gmail.com', 'earl12345', 'Villaluna', 'Earl', 'Dela Cruz', 23, 'Male', 'Blk. 35 Lot 20 Margo', '09785631125', 'Barangay Treasurer', 'user', 'Vilfamat, Vincent');

--
-- Indexes for dumped tables
--

--
-- Indexes for table tbl_admin
--
ALTER TABLE tbl_admin
  ADD PRIMARY KEY (id_admin);

--
-- Indexes for table tbl_announcement
--
ALTER TABLE tbl_announcement
  ADD PRIMARY KEY (id_announcement);

--
-- Indexes for table tbl_blotter
--
ALTER TABLE tbl_blotter
  ADD PRIMARY KEY (id_blotter),
  ADD KEY id_resident (id_resident);

--
-- Indexes for table tbl_brgyid
--
ALTER TABLE tbl_brgyid
  ADD PRIMARY KEY (id_brgyid),
  ADD KEY id_resident (id_resident);

--
-- Indexes for table tbl_bspermit
--
ALTER TABLE tbl_bspermit
  ADD PRIMARY KEY (id_bspermit),
  ADD KEY id_resident (id_resident);

--
-- Indexes for table tbl_clearance
--
ALTER TABLE tbl_clearance
  ADD PRIMARY KEY (id_clearance),
  ADD KEY id_resident (id_resident);

--
-- Indexes for table tbl_indigency
--
ALTER TABLE tbl_indigency
  ADD PRIMARY KEY (id_indigency),
  ADD KEY id_resident (id_resident);

--
-- Indexes for table tbl_rescert
--
ALTER TABLE tbl_rescert
  ADD PRIMARY KEY (id_rescert),
  ADD KEY id_resident (id_resident);

--
-- Indexes for table tbl_resident
--
ALTER TABLE tbl_resident
  ADD PRIMARY KEY (id_resident);

--
-- Indexes for table tbl_user
--
ALTER TABLE tbl_user
  ADD PRIMARY KEY (id_user);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table tbl_admin
--
ALTER TABLE tbl_admin
  MODIFY id_admin int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table tbl_announcement
--
ALTER TABLE tbl_announcement
  MODIFY id_announcement int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table tbl_blotter
--
ALTER TABLE tbl_blotter
  MODIFY id_blotter int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table tbl_brgyid
--
ALTER TABLE tbl_brgyid
  MODIFY id_brgyid int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table tbl_bspermit
--
ALTER TABLE tbl_bspermit
  MODIFY id_bspermit int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table tbl_clearance
--
ALTER TABLE tbl_clearance
  MODIFY id_clearance int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table tbl_indigency
--
ALTER TABLE tbl_indigency
  MODIFY id_indigency int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table tbl_rescert
--
ALTER TABLE tbl_rescert
  MODIFY id_rescert int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table tbl_resident
--
ALTER TABLE tbl_resident
  MODIFY id_resident int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table tbl_user
--
ALTER TABLE tbl_user
  MODIFY id_user int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
