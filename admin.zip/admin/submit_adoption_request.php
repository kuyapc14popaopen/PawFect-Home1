<?php
// Include the config file
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $email = $_POST['email'];
    $petName = $_POST['pet_name'];
    $petPicture = $_POST['pet_picture'];

    // Escape the form data to prevent SQL injection
    $email = mysqli_real_escape_string($db, $email);
    $petName = mysqli_real_escape_string($db, $petName);
    $petPicture = mysqli_real_escape_string($db, $petPicture);

    // Insert adoption request into the table
    $sql = "INSERT INTO adoption_request (email, pet_name, pet_picture) VALUES ('$email', '$petName', '$petPicture')";
    
    if (mysqli_query($db, $sql)) {
        // Adoption request successfully inserted
        // You can perform additional actions here if needed
        http_response_code(200); // Success response code
        echo "Adoption request submitted successfully!";
    } else {
        // Error inserting adoption request
        http_response_code(500); // Internal server error
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }

    // Close the database connection
    mysqli_close($db);
} else {
    // If the script is accessed directly without a POST request
    http_response_code(403); // Forbidden
    echo "Access denied";
}
?>
