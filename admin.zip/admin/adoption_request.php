<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the config file
include("config.php");

// Fetch adoption requests from the database
$sql = "SELECT * FROM adoption_request";
$result = $db->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoption Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            background-color: #4caf50; /* Green background color */
            padding: 10px 20px;
            color: white; /* White text color */
        }

        .back-btn {
            background-color: #3e8e41; /* Darker green color */
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #3d8b3f; /* Darker color on hover */
        }

        h2 {
            color: #fff;
            margin: 0;
        }

.adoption-container {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
}

.adoption-box {
    border: 1px solid #dddddd;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    background-color: #ffffff;
    transition: box-shadow 0.3s;
    width: calc(33.33% - 20px);
    box-sizing: border-box;
}

.adoption-box:hover {
    box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2);
}

.adoption-image {
    width: 100%;
    height: 180px;
    overflow: hidden;
}

.adoption-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.adoption-info {
    padding: 20px;
}

.pet-name {
    font-size: 1.2rem;
    font-weight: bold;
    margin-bottom: 10px;
}

.btn-container {
    display: flex;
    justify-content: center;
    margin-top: 10px;
}

.btn-container button {
    padding: 8px 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-bottom: 20px;
}

.btn-container button.confirm-btn {
    background-color: #4caf50;
    color: white;
}

.btn-container button.reject-btn {
    background-color: #f44336;
    color: white;
    margin-left: 3px;
}

.btn-container button:hover {
    background-color: #3e8e41;
}

.no-requests {
    width: 100%;
    padding: 20px;
    text-align: center;
    background-color: #f2f2f2;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

    </style>
</head>

<body>
    <header class="header">
        <h2>Adoption Requests</h2>
        <a href="index.html"><button class="back-btn">Back</button></a>
    </header>

<div class="adoption-container">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='adoption-box'>";
            echo "<div class='adoption-image'>";
            echo "<img src='" . $row["pet_picture"] . "' alt='Pet Image'>";
            echo "</div>";
            echo "<div class='adoption-info'>";
            echo "<p class='pet-name'>" . $row['pet_name'] . "</p>";
            echo "<p><strong>ID:</strong> " . $row['id'] . "</p>";
            echo "<p><strong>Email:</strong> " . $row['email'] . "</p>";
            echo "</div>";
            echo "<div class='btn-container'>";
            echo "<button class='confirm-btn' onclick='confirmAdoption(" . $row['id'] . ", \"" . $row['pet_name'] . "\")'>Confirm</button>";
            echo "<button class='reject-btn' onclick='rejectAdoption(" . $row['id'] . ")'>Reject</button>";
            echo "</div>";
            echo "</div>";
        }
    } else {
        echo "<div class='no-requests'>No adoption requests found.</div>";
    }
    ?>
</div>


    <script>
        function goBack() {
            window.history.back();
        }

        function confirmAdoption(requestId, petName) {
            var confirmed = confirm("Are you sure you want to confirm adoption of " + petName + "?");
            if (confirmed) {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            alert('Adoption confirmed for ' + petName);
                            // Reload the page or update the UI as needed
                            window.location.reload(); // Example: reload the page
                        } else {
                            alert('Error: ' + xhr.status);
                        }
                    }
                };

                // Create URL-encoded data string
                var data = 'request_id=' + encodeURIComponent(requestId);

                xhr.open('POST', 'confirm_adoption.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.send(data);
            }
        }

        function rejectAdoption(requestId) {
            var confirmed = confirm("Are you sure you want to reject this adoption request?");
            if (confirmed) {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            alert('Adoption request rejected.');
                            // Reload the page or update the UI as needed
                            window.location.reload(); // Example: reload the page
                        } else {
                            alert('Error: ' + xhr.status);
                        }
                    }
                };

                // Create URL-encoded data string
                var data = 'request_id=' + encodeURIComponent(requestId);

                xhr.open('POST', 'reject_adoption.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.send(data);
            }
        }
    </script>
</body>

</html>

<?php
// Close database connection
$db->close();
?>