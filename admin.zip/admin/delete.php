<?php
// delete.php

$db = new mysqli("localhost", "root", "", "user_db");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $petId = $_GET['id'];

    // Perform deletion query
    $deleteQuery = "DELETE FROM pets WHERE id = $petId";
    $db->query($deleteQuery);
}

$db->close();

// Redirect back to admin.php after deletion
header("Location: admin.php");
exit;
?>
