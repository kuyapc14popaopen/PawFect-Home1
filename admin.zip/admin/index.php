<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the config file
include("config.php");

// Establish a database connection (replace with your actual credentials)
$db = new mysqli("localhost", "root", "", "user_db");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Fetch pet data from the database
$result = $db->query("SELECT * FROM pets");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1300px; /* Increased container width */
            margin: 20px auto;
            padding: 20px;
            border: 0px solid #fff;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #4caf50;
            text-align: center;
        }

        .pet-grid {
            align-items: center;
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns for 3x3 grid */
            gap: 15px;
            margin-right: -75px;
        }

        .pet-card {
            width: calc((230% - 40px) / 3); /* Full width of the grid cell with gap */
            max-height: 570px;
            padding: 20px;
            border: 2px solid #4caf50;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .pet-image {
            width: 100%;
            max-height: 270px; /* Limit maximum height */
            object-fit: cover; /* Maintain aspect ratio and cover container */
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .pet-details {
            font-size: 18px;
        }

        .adopt-btn {
            margin-top: auto;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out;
            font-size: 16px;
        }

        button:hover {
            background-color: black;
            border-color: #45a049;
        }

        header {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
        }

        header a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, border 0.3s ease-in-out;
            border: 0px solid #fff;
            background-color: #45a049; /* Updated background color */
        }

        header a:hover {
            background-color: black;
            border-color: #45a049;
        }

        /* Pop up form styles */
        .popup-form {
            display: none;
            position: fixed;
            z-index: 999;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            padding: 20px;
            max-width: 300px;
            width: 100%;
            text-align: center;
        }

        .popup-form input {
            display: block;
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .popup-form button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out;
        }

        .popup-form button:hover {
            background-color: #45a049;
        }

        .adopted-label {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #4caf50;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
            font-weight: bold;
        }
    </style>
    </head>

<body>
    <header>
        <h1>Pawfect Home</h1>
        <a href="http://localhost/PawfectHomet/PawfectHomet/Pawfect%20Home/homepage.php">Home</a>
    </header>

    <div class="container">
        <h2>Adoptable Pets</h2>
        <div class="pet-grid">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Set the $picture and $adopted variables
                    $picture = htmlspecialchars($row['picture']);
                    $adopted = isset($row['adopted']) && $row['adopted'] ? 'Adopted' : ''; // Check if pet is adopted

                    // Display each pet in an enhanced card
                    echo '<div class="pet-card">';
                    if (!empty($adopted)) {
                        echo '<div class="adopted-label">' . $adopted . '</div>'; // Display Adopted label
                    }
                    echo '<img class="pet-image" src="' . $picture . '" alt="' . htmlspecialchars($row['name']) . '">';
                    echo '<div class="pet-details">';
                    echo '<h3>' . htmlspecialchars($row['name']) . '</h3>';
                    echo '<p><strong>Breed:</strong> ' . htmlspecialchars($row['breed']) . '</p>';
                    echo '<p><strong>Age:</strong> ' . htmlspecialchars($row['age']) . ' months </p>';
                    echo '<p><strong>Description:</strong> ' . htmlspecialchars($row['description']) . '</p>';
                    echo '</div>';
                    // Add an adopt button to each pet card
                    echo '<div class="adopt-btn">';
                    echo '<button onclick="openAdoptPopup(\'' . htmlspecialchars($row['name']) . '\', \'' . $picture . '\')">Adopt</button>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No pets found in the database.</p>';
            }

            $db->close();
            ?>
        </div>
    </div>

    <!-- Pop up form -->
    <div class="popup-form" id="adoptPopup">
        <form id="adoptForm" method="post" action="submit_adoption_request.php" onsubmit="return submitAdoptForm()">
            <input type="email" id="email" name="email" placeholder="Enter Your Email" required>
            <input type="hidden" id="petName" name="pet_name">
            <input type="hidden" id="petPicture" name="pet_picture">
            <button type="submit">Adopt</button>
            <!-- Add link to direct to the provided email link -->
            <a href="https://mail.google.com/mail/u/0/#inbox?compose=new" target="_blank">Email Us</a>
        </form>
    </div>

    <script>
        // Function to open the adopt popup form
        function openAdoptPopup(petName, petPicture) {
            document.getElementById('petName').value = petName;
            document.getElementById('petPicture').value = petPicture;
            document.getElementById('adoptPopup').style.display = 'block';
        }

        // Function to close the popup form
        function closePopup() {
            document.getElementById('adoptPopup').style.display = 'none';
        }

        // Function to submit the adopt form
        function submitAdoptForm() {
            var form = document.getElementById('adoptForm');
            var formData = new FormData(form);
            var xhr = new XMLHttpRequest();

            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        alert('Adoption request submitted successfully! Thank you for adopting ' + document.getElementById('petName').value);
                        closePopup();
                        form.reset(); // Reset the form after successful submission
                    } else {
                        alert('Error: ' + xhr.status);
                    }
                }
            };

            xhr.open('POST', 'submit_adoption_request.php', true);
            xhr.send(formData);

            form.querySelector('button[type="submit"]').disabled = true; // Disable the submit button to prevent multiple submissions

            return false; // Prevent default form submission
        }
    </script>

</body>

</html>