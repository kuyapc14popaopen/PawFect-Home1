<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px; /* Increased container width */
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #4caf50;
            text-align: center;
        }

        h3 {
    display: block;
    font-size: 1.17em;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    margin-left: 20px;
    font-weight: bold;
}

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input,
        textarea {
            width: 700px; /* Set the width to 100% */
            padding: 12px;
            margin-bottom: 12px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            max-width: 150px;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .table-container {
            max-width: 1000px; /* Match the width of the form container */
            margin: 20px auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #4caf50;
            color: #fff;
        }

        td img {
            display: block;
            margin: 0 auto;
            max-width: 100px;
            height: auto;
        }

        tbody tr:hover {
            background-color: #f2f2f2;
            transition: background-color 0.3s ease-in-out;
        }

        .edit-button {
            background-color: #4caf50;
            color: #fff;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .edit-button:hover {
            background-color: black;
        }
        header {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
        }

        header a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, border 0.3s ease-in-out;
            border: 0px solid #fff;
            background-color: #45a049; /* Updated background color */
        }

        header a:hover {
            background-color: black;
            border-color: #45a049;
        }

.footer {
  background-color: #4CAF50; /* Dark green */
  color: white;
  padding: 2em;
  display: flex;
  justify-content: space-around;
  align-items: flex-start;
  flex-wrap: wrap;
}

.footer a {
  display: inline;
  color: transparent;

}

.footer a:hover {
  background-color: #5E8B7E; /* Darker green on hover */
}

.footer h2 {
  font-size: 18px;
  margin-bottom: 10px;
}

.footer p {
  margin: 5px 0;
}

.social-media a {
  margin-right: 10px;
}

/* Add your social media icons styles here */
.social-media img {
  width: 30px;
  height: 30px;
  border-radius: 
}

.social-button {
    background-color: #7BB1A2; /* Orange button color */
    color: #F2F4E8;
    padding: 12px; /* Increase padding for larger buttons */
    margin: 0 5px; /* Add spacing between buttons */
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none; /* Remove underline for links */
    font-size: 28px; /* Increase font size for icons */
    transition: background-color 0.3s ease-in-out;
}

.social-button:hover {
    background-color: #5E8B7E; /* Darker orange on hover */
}
    </style>
</head>

<body>

    <header>
        <h1>Pawfect Home</h1>
        <a href="index.html">Home</a>
    </header>

    <section id="content">
        

    <!-- Display existing pets -->
    <div class="table-container">
        <h3>Existing Pets:</h3>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Breed</th>
                    <th>Age</th>
                    <th>Description</th>
                    <th>Picture</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Connect to the database (replace with your actual credentials)
                $db = new mysqli("localhost", "root", "", "user_db");

                if ($db->connect_error) {
                    die("Connection failed: " . $db->connect_error);
                }

                // Function to display a row with edit and delete buttons
                function displayTableRowWithEditAndDeleteButtons($row)
                {
                    echo "<tr>";
                    echo "<td>{$row['name']}</td>";
                    echo "<td>{$row['breed']}</td>";
                    echo "<td>{$row['age']}</td>";
                    echo "<td>{$row['description']}</td>";
                    echo "<td><img src='{$row['picture']}' alt='{$row['name']}' style='max-width: 100px; height: auto;'></td>";
                    echo "<td>
                            <a href='edit.php?id={$row['id']}' class='edit-button'>Edit</a>
                            <button onclick='confirmDelete({$row['id']})' class='edit-button'>Delete</button>
                          </td>"; // Edit and Delete buttons with links to edit.php and delete.php
                    echo "</tr>";
                }

                // Fetch pet data from the database
                $result = $db->query("SELECT * FROM pets");

                // Display existing pets with Edit button
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        displayTableRowWithEditAndDeleteButtons($row);
                    }
                } else {
                    echo "<tr><td colspan='6'>No pets found</td></tr>";
                }
                echo "</tbody>";
                echo "</table>";

                $db->close();
                ?>
            </tbody>
        </table>
    </div>

        <div class="container">
        <h2>Admin Panel</h2>

        <form action="process.php" method="post" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" name="name" required placeholder="Name of the pet">

            <label for="breed">Breed:</label>
            <input type="text" name="breed" required placeholder="Breed of the pet">

            <label for="age">Age:</label>
            <input type="number" name="age" required max="192" required min="0" placeholder="Age of the pet (month/s)">

            <label for="description">Description:</label>
            <textarea name="description" required placeholder="Describe the traits of the pet"></textarea>

            <label for="picture">Picture:</label>
            <input type="file" name="picture" accept="./uploads/image/*" required>
            <br>
            <input type="submit" value="Add Pet">
        </form>
    </div>
<footer class="footer">
  <div class="contact" id="about-us">
    <h2>Contact Us</h2>
    <p>Email: contact@pawfecthome.com</p>
    <p>Phone: +1 123-456-7890</p>
  </div>

  <div class="social-media">
    <h2>Follow Us</h2>
    <!-- Add your social media icons and links here -->
    <a href="#" target="_blank"><img src="facebook-icon.png" alt="Facebook"></a>
    <a href="#" target="_blank"><img src="twitter-icon.png" alt="Twitter"></a>
    <a href="#" target="_blank"><img src="instagram-icon.png" alt="Instagram"></a>
  </div>

  <div class="location">
    <h2>Our Location</h2>
    <p>123 Pet Street, Cityville, Country</p>
  </div>

  <div class="developers">
    <h2>Developers</h2>
    <p>John Doe</p>
    <p>Jane Smith</p>
  </div>
</footer>
    <script>
        function confirmDelete(petId) {
            var confirmDelete = confirm("Are you sure you want to delete this pet?");
            if (confirmDelete) {
                window.location.href = 'delete.php?id=' + petId;
            }
        }
    </script>
</body>

</html>
