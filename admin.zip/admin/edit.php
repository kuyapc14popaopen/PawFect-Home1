<?php
// edit.php

// Establish a database connection
$db = new mysqli("localhost", "root", "", "user_db");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Check if the ID parameter is set in the URL
if (isset($_GET['id'])) {
    $petId = $_GET['id'];

    // Fetch pet data based on the ID
    $result = $db->query("SELECT * FROM pets WHERE id = $petId");

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $breed = $row['breed'];
        $age = $row['age'];
        $description = $row['description'];
        $picture = $row['picture'];

        // Process form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve updated data from the form
            $name = $_POST['name'];
            $breed = $_POST['breed'];
            $age = $_POST['age'];
            $description = $_POST['description'];

            // Update the pet information in the database
            $updateQuery = "UPDATE pets SET name='$name', breed='$breed', age=$age, description='$description' WHERE id=$petId";

            if ($db->query($updateQuery) === TRUE) {
                echo "Pet information updated successfully!";
            } else {
                echo "Error updating pet information: " . $db->error;
            }
        }
    } else {
        echo "Pet not found.";
    }
} else {
    echo "Invalid request. Please provide a pet ID.";
}

$db->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pet</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px; /* Increased container width */
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #4caf50;
            text-align: center;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input,
        textarea {
            width: 700px; /* Set the width to 100% */
            padding: 12px;
            margin-bottom: 12px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            max-width: 150px;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        header {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
        }

        header a {
            margin-right: 10px; /* Add margin between links */
            color: #fff;
            text-decoration: none;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, border 0.3s ease-in-out;
            border: 0px solid #fff;
            background-color: #45a049; /* Updated background color */
        }

        header a:last-child {
            margin-right=: 0; /* Remove margin for the last link */
        }

        header a:hover {
            background-color: black;
            border-color: #45a049;
        }

        footer {
            background-color: #4CAF50; /* Dark green */
            color: white;
            padding: 2em;
            display: flex;
            justify-content: space-around;
            align-items: flex-start;
            flex-wrap: wrap;
            margin-top: 20px; /* Added margin to separate from the form */
            max-height: 100%;
        }

        footer a {
            display: inline;
            color: transparent;
        }

        footer a:hover {
            background-color: #5E8B7E; /* Darker green on hover */
        }

        footer h2 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        footer p {
            margin: 5px 0;
        }

        .social-media a {
            margin-right: 10px;
        }

        .social-media img {
            width: 30px;
            height: 30px;
            border-radius: 5px; /* Added border-radius */
        }

        .social-button {
            background-color: #7BB1A2; /* Orange button color */
            color: #F2F4E8;
            padding: 12px; /* Increase padding for larger buttons */
            margin: 0 5px; /* Add spacing between buttons */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none; /* Remove underline for links */
            font-size: 28px; /* Increase font size for icons */
            transition: background-color 0.3s ease-in-out;
        }

        .social-button:hover {
            background-color: #5E8B7E; /* Darker orange on hover */
        }
    </style>
</head>

<body>

    <header>
        <h1>Pawfect Home</h1>
        <a href="admin.php">Back</a>
    </header>

    <section id="content">
        <div class="container">
            <h2>Edit Pet Information</h2>

            <form action="" method="post">
                <label for="name">Name:</label>
                <input type="text" name="name" value="<?php echo $name; ?>" required>

                <label for="breed">Breed:</label>
                <input type="text" name="breed" value="<?php echo $breed; ?>" required>

                <label for="age">Age:</label>
                <input type="number" name="age" required max="192" required min="0" placeholder="Age of the pet (month/s)" value="<?php echo $age; ?>" >

                <label for="description">Description:</label>
                <textarea name="description" required><?php echo $description; ?></textarea>

                <label for="picture">Picture:</label>
                <input type="file" name="picture" value="<?php echo $picture; ?>" required>

                <br><input type="submit" value="Update Pet">
            </form>
        </div>
    </section>

    <footer class="footer">
        <div class="contact" id="about-us">
            <h2>Contact Us</h2>
            <p>Email: contact@pawfecthome.com</p>
            <p>Phone: +1 123-456-7890</p>
        </div>

        <div class="social-media">
            <h2>Follow Us</h2>
            <!-- Add your social media icons and links here -->
            <a href="#" target="_blank"><img src="facebook-icon.png" alt="Facebook"></a>
            <a href="#" target="_blank"><img src="twitter-icon.png" alt="Twitter"></a>
            <a href="#" target="_blank"><img src="instagram-icon.png" alt="Instagram"></a>
        </div>

        <div class="location">
            <h2>Our Location</h2>
            <p>123 Pet Street, Cityville, Country</p>
        </div>

        <div class="developers">
            <h2>Developers</h2>
            <p>John Doe</p>
            <p>Jane Smith</p>
        </div>
    </footer>

    <script>
        function confirmDelete(petId) {
            var confirmDelete = confirm("Are you sure you want to delete this pet?");
            if (confirmDelete) {
                window.location.href = 'delete.php?id=' + petId;
            }
        }
    </script>
</body>

</html>
