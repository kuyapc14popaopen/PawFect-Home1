<?php
// Establish a database connection (replace with your actual credentials)
$db = new mysqli("localhost", "root", "", "user_db");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $breed = $_POST["breed"];
    $age = $_POST["age"];
    $description = $_POST["description"];

    // Upload picture
    $picture = "uploads/" . basename($_FILES["picture"]["name"]);
    move_uploaded_file($_FILES["picture"]["tmp_name"], $picture);

    // Insert data into the database
    $query = "INSERT INTO pets (name, breed, age, description, picture) VALUES ('$name', '$breed', $age, '$description', '$picture')";

    if ($db->query($query) === TRUE) {
        echo "Pet added successfully!";
    } else {
        echo "Error: " . $query . "<br>" . $db->error;
    }
}

$db->close();
?>
