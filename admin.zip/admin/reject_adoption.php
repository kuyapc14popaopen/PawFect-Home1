<?php
// Include the config file
include("config.php");

// Check if request_id is set and not empty
if (isset($_POST['request_id']) && !empty($_POST['request_id'])) {
    // Sanitize the input to prevent SQL injection
    $requestId = $db->real_escape_string($_POST['request_id']);

    // Perform the deletion from the database
    $sql = "DELETE FROM adoption_request WHERE id = '$requestId'";
    if ($db->query($sql) === TRUE) {
        echo "Adoption request rejected and deleted successfully";
    } else {
        echo "Error deleting record: " . $db->error;
    }
} else {
    echo "Invalid request";
}

// Close database connection
$db->close();
?>