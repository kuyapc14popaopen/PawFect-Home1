<?php
// Include the config file
include("config.php");

// Check if request_id is set and not empty
if (isset($_POST['request_id']) && !empty($_POST['request_id'])) {
    // Sanitize the input to prevent SQL injection
    $requestId = $db->real_escape_string($_POST['request_id']);

    // Perform the confirmation action (update your database table accordingly)
    $sql = "UPDATE adoption_request SET status = 'confirmed' WHERE id = '$requestId'";
    if ($db->query($sql) === TRUE) {
        echo "Adoption confirmed successfully";
    } else {
        echo "Error updating record: " . $db->error;
    }
} else {
    echo "Invalid request";
}

// Close database connection
$db->close();
?>
