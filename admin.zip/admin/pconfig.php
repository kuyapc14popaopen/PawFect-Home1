<?php

$conn = mysqli_connect('localhost','root','','pet_database');

?>