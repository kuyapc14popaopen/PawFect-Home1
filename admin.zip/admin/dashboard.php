<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the config file
include("config.php");

// Fetch adoption requests from the database
$sql = "SELECT * FROM adoption_request";
$result = $db->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <!-- My CSS -->
    <link rel="stylesheet" href="styles.css">

    <title>AdminHub</title>

</head>
<body>


    <!-- SIDEBAR -->
    <section id="sidebar">


        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Pawfect Home</span>
        </a>

        <ul class="side-menu top">
            <li class="active" data-content="dashboard">
                <a href="#">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>

            <li data-content="chart">
                <a href="#">
                    <i class='bx bxs-doughnut-chart'></i>
                    <span class="text">Chart</span>
                </a>
            </li>
            <li data-content="manage-users">
                <a href="#">
                    <i class='bx bxs-group'></i>
                    <span class="text">Manage Users</span>
                </a>
            </li>

            <li data-content="manage-pets">
                <a href="#">
                    <i class='bx bxs-group'></i>
                    <span class="text">Manage Pets</span>
                </a>
            </li>

            <li data-content="adoption-requests">
                <a href="#">
                    <i class='bx bxs-group'></i>
                    <span class="text">Adoption Requests</span>
                </a>
            </li>
        </ul>

        <ul class="side-menu">
            <li>
                <a href="#">
                    <i class='bx bxs-cog'></i>
                    <span class="text">Settings</span>
                </a>
            </li>
            <li>
                <a href="#" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->



    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>

            <form action="#">

            </form>
            <a href="#" class="profile">
                <img src="img/icon.jpg">
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->

        <main>
            <section id="dashboard" class="content-section">
                <div class="box-container">
                    <div class="box-item">
                        <h3>Box 1</h3>
                        <p>This is Box 1 content.</p>
                    </div>
                    <div class="box-item">
                        <h3>Box 2</h3>
                        <p>This is Box 2 content.</p>
                    </div>
                    <div class="box-item">
                        <h3>Box 3</h3>
                        <p>This is Box 3 content.</p>
                    </div>
                    <div class="box-item">
                        <h3>Box 4</h3>
                        <p>This is Box 4 content.</p>
                    </div>
                    <div class="box-item">
                        <h3>Box 5</h3>
                        <p>This is Box 5 content.</p>
                    </div>
                    <div class="box-item">
                        <h3>Box 6</h3>
                        <p>This is Box 6 content.</p>
                    </div>
                </div>
            </section>
            <section id="chart" class="content-section" style="display: none;">
                <h2>Chart Content</h2>
                <p>This is the content for the Chart.</p>
            </section>
            <section id="manage-users" class="content-section" style="display: none;">
    <?php
    // Database connection
    $conn = mysqli_connect('localhost', 'root', '', 'user_db');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Handle blocking user
    if (isset($_POST['block_user'])) {
        $user_id = $_POST['block_user'];
        $sql_block = "UPDATE user_form SET user_type='blocked' WHERE id=$user_id";
        if (mysqli_query($conn, $sql_block)) {
            // No message here, removed the success message
        } else {
            echo "<div class='header'>
                <h2>Error Blocking User: " . mysqli_error($conn) . "</h2>
            </div>";
        }
    }

    // Handle unblocking user
    if (isset($_POST['unblock_user'])) {
        $user_id = $_POST['unblock_user'];
        $sql_unblock = "UPDATE user_form SET user_type='user' WHERE id=$user_id";
        if (mysqli_query($conn, $sql_unblock)) {
            // No message here, removed the success message
        } else {
            echo "<div class='header'>
                <h2>Error Unblocking User: " . mysqli_error($conn) . "</h2>
            </div>";
        }
    }

    function getLoggedInUsers($conn) {
        // Query to get the logged-in users from the user_form table
        $sql = "SELECT * FROM user_form";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            // Start table with improved design
            echo "<table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>User Type</th>
                    <th>Action</th>
                </tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["password"] . "</td>";
                echo "<td>" . $row["user_type"] . "</td>";
                // Action buttons
                echo "<td>";
                if ($row["user_type"] === 'blocked') {
                    // Unblock button form with confirmation
                    echo "<form method='post'>
                        <input type='hidden' name='unblock_user' value='" . $row["id"] . "'>
                        <button type='submit' class='unblock-btn' onclick=\"return confirm('Are you sure you want to unblock this user?')\">Unblock</button>
                    </form>";
                } else {
                    // Block button form with confirmation
                    echo "<form method='post'>
                        <input type='hidden' name='block_user' value='" . $row["id"] . "'>
                        <button type='submit' class='block-btn' onclick=\"return confirm('Are you sure you want to block this user?')\">Block</button>
                    </form>";
                }
                echo "</td>";
                echo "</tr>";
            }

            echo "</table>";

            // Display total count of logged-in users
            echo "<div class='footer'>
                <p>Total Logged-In Users: " . mysqli_num_rows($result) . "</p>
            </div>";
        } else {
            echo "<div class='header'>
                <h2>No Logged-In Users Found</h2>
            </div>";
        }
    }

    // Call the function to display logged-in users
    getLoggedInUsers($conn);

    // Close connection
    mysqli_close($conn);
    ?>
            </section>
            <section id="manage-pets" class="content-section" style="display: none;">
                <h2>Manage Pets Content</h2>
                <p>This is the content for managing pets.</p>
            </section>
            <section id="adoption-requests" class="content-section" style="display: none;">
<div class="adoption-container">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='adoption-box'>";
            echo "<div class='adoption-image'>";
            echo "<img src='" . $row["pet_picture"] . "' alt='Pet Image'>";
            echo "</div>";
            echo "<div class='adoption-info'>";
            echo "<p class='pet-name'>" . $row['pet_name'] . "</p>";
            echo "<p><strong>ID:</strong> " . $row['id'] . "</p>";
            echo "<p><strong>Email:</strong> " . $row['email'] . "</p>";
            echo "</div>";
            echo "<div class='btn-container'>";
            echo "<button class='confirm-btn' onclick='confirmAdoption(" . $row['id'] . ", \"" . $row['pet_name'] . "\")'>Confirm</button>";
            echo "<button class='reject-btn' onclick='rejectAdoption(" . $row['id'] . ")'>Reject</button>";
            echo "</div>";
            echo "</div>";
        }
    } else {
        echo "<div class='no-requests'>No adoption requests found.</div>";
    }
    ?>
</div>
            </section>
        </main>
        <!-- MAIN -->
    </section>

    <script src="script.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const sideMenuItems = document.querySelectorAll(".side-menu li");

            sideMenuItems.forEach(function (item) {
                item.addEventListener("click", function (event) {
                    // Prevent default link behavior
                    event.preventDefault();

                    // Get the data-content attribute value
                    const contentId = item.getAttribute("data-content");

                    // Hide all content sections
                    const contentSections = document.querySelectorAll(".content-section");
                    contentSections.forEach(function (section) {
                        section.style.display = "none";
                    });

                    // Show the selected content section
                    const selectedContent = document.getElementById(contentId);
                    if (selectedContent) {
                        selectedContent.style.display = "block";
                    }

                    // Optionally, you can add logic to handle active state for the clicked item
                    // For example, remove 'active' class from all items and add it to the clicked item
                    sideMenuItems.forEach(function (menuItem) {
                        menuItem.classList.remove("active");
                    });
                    item.classList.add("active");
                });
            });
        });

                function goBack() {
            window.history.back();
        }

        function confirmAdoption(requestId, petName) {
            var confirmed = confirm("Are you sure you want to confirm adoption of " + petName + "?");
            if (confirmed) {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            alert('Adoption confirmed for ' + petName);
                            // Reload the page or update the UI as needed
                            window.location.reload(); // Example: reload the page
                        } else {
                            alert('Error: ' + xhr.status);
                        }
                    }
                };

                // Create URL-encoded data string
                var data = 'request_id=' + encodeURIComponent(requestId);

                xhr.open('POST', 'confirm_adoption.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.send(data);
            }
        }

        function rejectAdoption(requestId) {
            var confirmed = confirm("Are you sure you want to reject this adoption request?");
            if (confirmed) {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            alert('Adoption request rejected.');
                            // Reload the page or update the UI as needed
                            window.location.reload(); // Example: reload the page
                        } else {
                            alert('Error: ' + xhr.status);
                        }
                    }
                };

                // Create URL-encoded data string
                var data = 'request_id=' + encodeURIComponent(requestId);

                xhr.open('POST', 'reject_adoption.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.send(data);
            }
        }
    </script>
</body>
</html>
