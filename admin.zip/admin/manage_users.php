<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            background-color: #4caf50; /* Green background color */
            padding: 10px 20px;
            color: white; /* White text color */
        }

        .back-btn {
            background-color: #3e8e41; /* Darker green color */
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #3d8b3f; /* Darker color on hover */
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 20px auto;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 12px;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        .footer {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .block-btn, .unblock-btn {
            background-color: #f44336;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

    </style>
</head>
<body>
    <header class="header">
        <h2>Adoption Requests</h2>
        <a href="index.html"><button class="back-btn">Back</button></a>
    </header>

    <?php
    // Database connection
    $conn = mysqli_connect('localhost', 'root', '', 'user_db');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Handle blocking user
    if (isset($_POST['block_user'])) {
        $user_id = $_POST['block_user'];
        $sql_block = "UPDATE user_form SET user_type='blocked' WHERE id=$user_id";
        if (mysqli_query($conn, $sql_block)) {
            // No message here, removed the success message
        } else {
            echo "<div class='header'>
                <h2>Error Blocking User: " . mysqli_error($conn) . "</h2>
            </div>";
        }
    }

    // Handle unblocking user
    if (isset($_POST['unblock_user'])) {
        $user_id = $_POST['unblock_user'];
        $sql_unblock = "UPDATE user_form SET user_type='user' WHERE id=$user_id";
        if (mysqli_query($conn, $sql_unblock)) {
            // No message here, removed the success message
        } else {
            echo "<div class='header'>
                <h2>Error Unblocking User: " . mysqli_error($conn) . "</h2>
            </div>";
        }
    }

    function getLoggedInUsers($conn) {
        // Query to get the logged-in users from the user_form table
        $sql = "SELECT * FROM user_form";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            // Start table with improved design
            echo "<table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>User Type</th>
                    <th>Action</th>
                </tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["password"] . "</td>";
                echo "<td>" . $row["user_type"] . "</td>";
                // Action buttons
                echo "<td>";
                if ($row["user_type"] === 'blocked') {
                    // Unblock button form with confirmation
                    echo "<form method='post'>
                        <input type='hidden' name='unblock_user' value='" . $row["id"] . "'>
                        <button type='submit' class='unblock-btn' onclick=\"return confirm('Are you sure you want to unblock this user?')\">Unblock</button>
                    </form>";
                } else {
                    // Block button form with confirmation
                    echo "<form method='post'>
                        <input type='hidden' name='block_user' value='" . $row["id"] . "'>
                        <button type='submit' class='block-btn' onclick=\"return confirm('Are you sure you want to block this user?')\">Block</button>
                    </form>";
                }
                echo "</td>";
                echo "</tr>";
            }

            echo "</table>";

            // Display total count of logged-in users
            echo "<div class='footer'>
                <p>Total Logged-In Users: " . mysqli_num_rows($result) . "</p>
            </div>";
        } else {
            echo "<div class='header'>
                <h2>No Logged-In Users Found</h2>
            </div>";
        }
    }

    // Call the function to display logged-in users
    getLoggedInUsers($conn);

    // Close connection
    mysqli_close($conn);
    ?>
</body>
</html>
