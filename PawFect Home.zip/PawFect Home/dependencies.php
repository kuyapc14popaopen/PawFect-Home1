
<link rel="shortcut icon" href="img/Bulldog.jpeg" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
<!-- jquery library -->
<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
<!-- Latest compiled and minified javascript -->
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script src="script/cropper.js" defer></script>
<script src="script/universal.js" defer></script>
<link rel="stylesheet" type="text/css" href="css/cropper.css">
<link rel="stylesheet" href="css/style.css" type="text/css">
      

