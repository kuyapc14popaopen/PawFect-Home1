<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the config file
include("config.php");

// Check if the database connection is successful
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

function submitAdoptionRequest($email, $pet_id, $pet_name, $pet_picture) {
    // Prepare and bind the SQL statement to prevent SQL injection
    $stmt = $db->prepare("INSERT INTO adoption_request (email, pet_name, pet_picture) VALUES (?, ?, ?)");

    // Check if the statement was prepared successfully
    if (!$stmt) {
        die("Error preparing statement: " . $db->error);
    }

    $stmt->bind_param("sss", $email, $pet_name, $pet_picture);

    // Set parameters and execute
    $stmt->execute();

    // Close statement
    $stmt->close();
}

// Close database connection
$db->close();
?>