<?php
@include './database/config.php';

session_start();

// Check if the user is logged in as an admin
if (isset($_SESSION['admin_name'])) {
    // Fetch all users from the database
    $query = "SELECT * FROM user_form";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $users = mysqli_fetch_all($result, MYSQLI_ASSOC);
    } else {
        $error = "Error fetching users.";
    }
} else {
    header('location: ./homepage.php'); // Redirect non-admin users to homepage
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="./sample/style.css">
</head>
<body>

    <div class="admin-container">
        <h2>Welcome, <?php echo $_SESSION['admin_name']; ?> (Admin)</h2>
        <a href="logout.php">Logout</a>

        <?php
        if (isset($error)) {
            echo '<span class="error-msg">' . $error . '</span>';
        } elseif (isset($users)) {
            echo '<table border="1">';
            echo '<tr><th>Name</th><th>Email</th><th>User Type</th></tr>';

            foreach ($users as $user) {
                echo '<tr>';
                echo '<td>' . $user['name'] . '</td>';
                echo '<td>' . $user['email'] . '</td>';
                echo '<td>' . $user['user_type'] . '</td>';
                echo '</tr>';
            }

            echo '</table>';
        }
        ?>
    </div>

</body>
</html>
